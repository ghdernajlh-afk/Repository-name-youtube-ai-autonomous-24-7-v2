@echo off
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo Setup complete.
echo Put Google OAuth JSON in credentials\client_secret.json
echo Then run run.bat
pause
